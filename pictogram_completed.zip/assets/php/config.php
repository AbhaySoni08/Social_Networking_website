<?php
session_start();
// mysqli database connection
const DB_NAME = 'pictogram';
const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASS = '';